 
For the Read from JSON generated file - genjson.php has to be located on a server
so if the directory is unzipped to directory on the server and the index.html is in the same directory as genjson.php then it should work ok.

there should be an online copy of the project on http://www.appwayz.com/webelevate/mobdev/assignment/index.html

Kind Regards
Conor Gilmer
